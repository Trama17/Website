import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class circleAreaConverter extends PApplet {

public void setup() {
  size(800,800);
}

public void draw() {
  background(0);
  textAlign(CENTER);
  textSize(32);
  fill(255);
  text("Area of a Circle Conversion",400,50);
  textAlign(LEFT);
  textSize(8);
  text("Trevor",2,8);
  text("Tateyama",2,15);
  textSize(12);
  drawReference(400,400);
  text("Radius = " + PApplet.parseInt(mouseX-400),50,100);
  text("Area = " + PApplet.parseInt(radiusToArea(mouseX-400)), 50,150);
  line(400,400,800,400);
//  println(mouseX,mouseY);
  
  /*to see fun circles and random colors uncomment 
  the next two lines and coment out the following two lines*/
  
  //fill(random(mouseY),random(mouseX),120,100);
  //ellipse(400,400,(mouseX-400)*2,(mouseY-400)*2);
  fill(0,255,120,100);
  ellipse(400,400,(mouseX-400)*2,(mouseX-400)*2);
}

public float radiusToArea(float radius) {
  float area = (radius * radius * 3.1415926f);
  return area;
}

public void drawReference(int xpos, int ypos) {
  stroke(255);
  for(int i=0; i<400; i+=50) {
    fill(255);
    text(i,xpos+i-8,ypos);
    line(xpos+i,ypos,xpos+i,ypos+10);
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "circleAreaConverter" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
